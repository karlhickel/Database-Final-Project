INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('steakLOB', 5841, 1);
INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('karlHickel', 5576800, 2);
INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('ander428', 1172367, 3);
INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('test', 0, 4);
INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('test1', 0, 5);
INSERT INTO FinalProject.balance (userName, balance, ID) VALUES ('fake', 0, 6);